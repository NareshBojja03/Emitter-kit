#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double EmitterKitVersionNumber;
FOUNDATION_EXPORT const unsigned char EmitterKitVersionString[];
